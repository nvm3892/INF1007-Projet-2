"""Tests du module graphiques."""

from matplotlib.figure import Figure

from donnees import CIBLE, nettoyer
from graphiques import enregistrer_figure, figure_exploration, figure_matrice_confusion


def test_figure_exploration_a_quatre_graphiques(donnees_brutes):
    figure = figure_exploration(nettoyer(donnees_brutes))
    assert isinstance(figure, Figure)
    assert len(figure.axes) == 4


def test_matrice_confusion_et_enregistrement(tmp_path, donnees_brutes):
    genres = sorted(donnees_brutes[CIBLE].unique())
    figure = figure_matrice_confusion(donnees_brutes[CIBLE], donnees_brutes[CIBLE], genres)

    assert figure.axes[0].get_title() == "Matrice de confusion"

    chemin = tmp_path / "figures" / "matrice.png"
    enregistrer_figure(figure, str(chemin))
    assert chemin.is_file() and chemin.stat().st_size > 0
