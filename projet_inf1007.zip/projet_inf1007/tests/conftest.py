"""Données de test fabriquées à la main : trois genres faciles à distinguer.

Les tests n'ont donc pas besoin du vrai CSV.
"""

import numpy as np
import pandas as pd
import pytest

from donnees import CIBLE, COLONNES_NUMERIQUES


@pytest.fixture
def donnees_brutes() -> pd.DataFrame:
    """300 chansons : 100 par genre, avec key et mode écrits en texte comme dans le CSV."""
    generateur = np.random.default_rng(0)
    blocs = []
    for genre, energie, tempo in [("Calme", 0.2, 80), ("Moyen", 0.5, 120), ("Fort", 0.9, 160)]:
        bloc = pd.DataFrame({c: generateur.uniform(0, 1, 100) for c in COLONNES_NUMERIQUES})
        bloc["energy"] = generateur.normal(energie, 0.05, 100)
        bloc["tempo"] = generateur.normal(tempo, 5, 100)
        bloc["duration_ms"] = generateur.integers(120_000, 300_000, 100)
        bloc["key"] = generateur.choice(["C", "D", "A"], 100)
        bloc["mode"] = generateur.choice(["Major", "Minor"], 100)
        bloc[CIBLE] = genre
        blocs.append(bloc)
    return pd.concat(blocs, ignore_index=True)


@pytest.fixture
def une_chanson(donnees_brutes) -> dict:
    """Les valeurs d'une chanson, comme l'interface les enverrait."""
    return donnees_brutes.drop(columns=[CIBLE]).iloc[0].to_dict()
