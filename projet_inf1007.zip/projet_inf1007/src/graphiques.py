"""Graphiques Matplotlib : exploration des données et évaluation du modèle.

Chaque fonction retourne une figure ; ``enregistrer_figure`` l'écrit en PNG
(et l'interface pourra afficher la même figure dans sa fenêtre).
"""

import os

import pandas as pd
from matplotlib.figure import Figure
from sklearn.metrics import confusion_matrix

from donnees import CIBLE

# (colonne, titre) des quatre graphiques d'exploration
CARACTERISTIQUES = [
    ("tempo", "Tempo (battements par minute)"),
    ("instrumentalness", "Instrumentalness (0 = voix, 1 = sans voix)"),
    ("energy", "Énergie (0 = calme, 1 = intense)"),
    ("speechiness", "Speechiness (présence de parole)"),
]


def figure_exploration(df: pd.DataFrame) -> Figure:
    """Compare les 10 genres sur 4 mesures avec des boîtes à moustaches.

    Une boîte contient la moitié centrale des chansons du genre ; le trait
    dans la boîte est la médiane.
    """
    genres = df.groupby(CIBLE)["tempo"].median().sort_values().index.tolist()
    figure = Figure(figsize=(14, 10))
    graphiques = figure.subplots(2, 2).ravel()
    for graphique, (colonne, titre) in zip(graphiques, CARACTERISTIQUES):
        valeurs = [df.loc[df[CIBLE] == genre, colonne] for genre in genres]
        graphique.boxplot(valeurs, orientation="horizontal", tick_labels=genres,
                          showfliers=False)
        graphique.set_title(titre)
        graphique.grid(axis="x", alpha=0.3)
    figure.tight_layout()
    return figure


def figure_matrice_confusion(y_vrai, y_pred, genres: list[str]) -> Figure:
    """Matrice de confusion : une ligne par genre réel, une colonne par genre prédit.

    Chaque case donne la part des chansons du genre réel que le modèle a rangées
    dans le genre prédit. Une bonne matrice a de grosses valeurs sur la diagonale.
    """
    comptes = confusion_matrix(y_vrai, y_pred, labels=genres)
    parts = comptes / comptes.sum(axis=1, keepdims=True)   # chaque ligne totalise 100 %
    figure = Figure(figsize=(9, 8))
    graphique = figure.subplots()
    graphique.imshow(parts, cmap="Blues", vmin=0, vmax=1)
    graphique.set_xticks(range(len(genres)), labels=genres, rotation=45, ha="right")
    graphique.set_yticks(range(len(genres)), labels=genres)
    graphique.set_xlabel("Genre prédit")
    graphique.set_ylabel("Genre réel")
    graphique.set_title("Matrice de confusion")
    for ligne in range(len(genres)):
        for colonne in range(len(genres)):
            graphique.text(colonne, ligne, f"{parts[ligne, colonne]:.0%}",
                           ha="center", va="center", fontsize=8)
    figure.tight_layout()
    return figure


def enregistrer_figure(figure: Figure, chemin: str) -> None:
    """Enregistre une figure en PNG (crée le dossier au besoin)."""
    os.makedirs(os.path.dirname(chemin) or ".", exist_ok=True)
    figure.savefig(chemin, dpi=120)
