# INF1007 — Projet 2 : de la donnée à l'application

> Équipe : _Prénom Nom_ et _Prénom Nom_ — Session A2026

## Description

Application qui devine le **genre musical** d'une chanson (Alternative, Anime, Blues, Classical, Country, Electronic, Hip-Hop, Jazz, Rap ou Rock) à partir de mesures audio : tempo, énergie, danceability, tonalité, etc. L'utilisateur règle les caractéristiques d'une chanson et obtient le genre le plus probable, avec la probabilité de chaque genre.

_Volet 3 (interface graphique) : à compléter par l'équipe._

## Jeu de données

- Nom : **Prediction of Music Genre** (Kaggle, utilisateur `vicsuperman`) — https://www.kaggle.com/datasets/vicsuperman/prediction-of-music-genre
- Contenu : 50 000 chansons, 10 genres de 5 000 chansons, 11 variables numériques et 2 catégorielles (`key`, `mode`).
- **Source d'origine et licence : non précisées sur la page du jeu de données.** Les colonnes ressemblent aux « audio features » de Spotify, mais l'auteur ne le confirme pas. _À compléter avec la licence affichée sur Kaggle._
- Nettoyage appliqué (`src/donnees.py`) : suppression des 5 lignes vides, des lignes dont le tempo vaut `?` ou la durée `-1` (codes de valeur inconnue, environ 20 % des lignes) et des colonnes inutiles (identifiant, nom de l'artiste, nom du titre, date). Résultat : **40 560 lignes**, environ 4 040 par genre. Les chansons avec `instrumentalness = 0` sont conservées : c'est une vraie valeur (chanson chantée), pas une valeur inconnue.
- Le fichier nettoyé se place dans `donnees/music_genre_clean.csv`.

## Installation et lancement

```bash
git clone https://github.com/nvm3892/INF1007-Projet-2.git
cd INF1007-Projet-2
python -m venv .venv
.venv\Scripts\activate           # Linux/macOS : source .venv/bin/activate
pip install -r requirements.txt
python src/main.py entrainer     # entraîne, évalue et sauvegarde le modèle
pytest                           # lance les tests
```

Le modèle sauvegardé (`modeles/modele_genre.joblib`) est un fichier binaire : il ne s'ouvre pas dans un éditeur de texte. S'il ne se charge pas à cause d'une version différente de scikit-learn, `python src/main.py entrainer` le régénère en quelques secondes.

## Structure du code

```
INF1007-Projet-2/
├── README.md, DECISIONS.md, JOURNAL_IA.md, requirements.txt
├── .github/workflows/tests.yml   # CI : pytest et couverture à chaque push
├── donnees/                      # music_genre_clean.csv
├── modeles/                      # modele_genre.joblib + metadonnees.json
├── figures/                      # graphique d'exploration, matrice de confusion
├── src/
│   ├── exceptions.py             # DonneeInvalideError, FichierIntrouvableError, ModeleNonEntraineError
│   ├── donnees.py                # lecture par blocs, nettoyage, classe JeuDeDonnees
│   ├── modele.py                 # Modele (abstraite) → ModeleReference, ModeleLogistique, ModeleForet
│   ├── graphiques.py             # graphique d'exploration et matrice de confusion
│   └── main.py                   # point d'entrée (entraînement ; interface à venir)
└── tests/                        # tests pytest de la logique
```

L'interface graphique (volet 3) s'appuiera sur `modeles/metadonnees.json` (genres, notes, modes, minimum et maximum de chaque mesure) et sur `Modele.predire_une_chanson`, qui renvoie le genre et la probabilité de chaque genre.

## Résultat du modèle

- **Cible :** `music_genre` (classification, 10 genres). **Métrique :** exactitude (part des chansons dont le genre est bien deviné). Séparation 80 % / 20 %, stratifiée, graine 42. Les mesures sont mises à la même échelle (`StandardScaler`) ; `key` et `mode` sont remplacés par leur position (C = 0, C# = 1…).
- Scores sur l'ensemble de test, jamais vu à l'entraînement :

| Modèle | Exactitude |
|---|---|
| Référence (toujours le genre majoritaire) | 10,1 % |
| Régression logistique | 53,5 % |
| **Forêt aléatoire (retenue)** | **56,4 %** |

- La forêt fait plus de cinq fois mieux que le hasard, mais se trompe encore presque une fois sur deux. Les confusions sont logiques (voir `figures/matrice_confusion.png`) : la moitié des chansons Rap sont classées Hip-Hop (et inversement), Alternative est le genre le moins bien reconnu (31 %, souvent pris pour du Rock), tandis que Classical (85 %), Rock (75 %) et Anime (74 %) sont les mieux reconnus.
- Limites : le genre est une étiquette humaine souvent floue, les mesures audio ne décrivent ni les paroles ni la culture d'un genre, et l'origine des données n'est pas documentée.

## Couverture des tests

31 tests pytest ; `coverage report` indique **83 %** sur `src/` (`main.py`, la ligne de commande, n'est pas testé).

## Outils du chapitre 7 utilisés

- **Décorateur** `chronometrer` : mesure la durée de chaque entraînement sans modifier le code de la méthode.
- **Générateur** `lire_csv_par_blocs` : lit le CSV par blocs de 10 000 lignes avec `yield`, au lieu de tout charger d'un coup.

## Documentation consultée

_À compléter après lecture, par exemple :_
- pandas : `read_csv` (paramètre `chunksize`) — https://pandas.pydata.org/docs/
- scikit-learn : `train_test_split`, `RandomForestClassifier` — https://scikit-learn.org/stable/
- Technologie d'interface : _page consultée_
